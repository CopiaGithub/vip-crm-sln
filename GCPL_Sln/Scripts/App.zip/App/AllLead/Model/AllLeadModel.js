var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var AllLeadsGridModel = /** @class */ (function () {
            function AllLeadsGridModel() {
            }
            return AllLeadsGridModel;
        }());
        Model.AllLeadsGridModel = AllLeadsGridModel;
        var ProjNameAutofill = /** @class */ (function () {
            function ProjNameAutofill() {
            }
            return ProjNameAutofill;
        }());
        Model.ProjNameAutofill = ProjNameAutofill;
        var ProjNoAutofill = /** @class */ (function () {
            function ProjNoAutofill() {
            }
            return ProjNoAutofill;
        }());
        Model.ProjNoAutofill = ProjNoAutofill;
        var Modelno = /** @class */ (function () {
            function Modelno() {
            }
            return Modelno;
        }());
        Model.Modelno = Modelno;
        var Product = /** @class */ (function () {
            function Product() {
            }
            return Product;
        }());
        Model.Product = Product;
        var AllLeadsHeaderModel = /** @class */ (function () {
            function AllLeadsHeaderModel() {
            }
            return AllLeadsHeaderModel;
        }());
        Model.AllLeadsHeaderModel = AllLeadsHeaderModel;
        var LeadSourceddModel = /** @class */ (function () {
            function LeadSourceddModel() {
            }
            return LeadSourceddModel;
        }());
        Model.LeadSourceddModel = LeadSourceddModel;
        var ActivityTypeddlModel = /** @class */ (function () {
            function ActivityTypeddlModel() {
            }
            return ActivityTypeddlModel;
        }());
        Model.ActivityTypeddlModel = ActivityTypeddlModel;
        var AllLeadReportViewModel = /** @class */ (function () {
            function AllLeadReportViewModel() {
            }
            return AllLeadReportViewModel;
        }());
        Model.AllLeadReportViewModel = AllLeadReportViewModel;
        var ValidateLeadInfoModel = /** @class */ (function () {
            function ValidateLeadInfoModel() {
            }
            return ValidateLeadInfoModel;
        }());
        Model.ValidateLeadInfoModel = ValidateLeadInfoModel;
        var CampaignAutofillModel = /** @class */ (function () {
            function CampaignAutofillModel() {
            }
            return CampaignAutofillModel;
        }());
        Model.CampaignAutofillModel = CampaignAutofillModel;
        var UserNameAutofillModel = /** @class */ (function () {
            function UserNameAutofillModel() {
            }
            return UserNameAutofillModel;
        }());
        Model.UserNameAutofillModel = UserNameAutofillModel;
        var ModelDDwpModel = /** @class */ (function () {
            function ModelDDwpModel() {
            }
            return ModelDDwpModel;
        }());
        Model.ModelDDwpModel = ModelDDwpModel;
        var LeadStatusModel = /** @class */ (function () {
            function LeadStatusModel() {
            }
            return LeadStatusModel;
        }());
        Model.LeadStatusModel = LeadStatusModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=AllLeadModel.js.map