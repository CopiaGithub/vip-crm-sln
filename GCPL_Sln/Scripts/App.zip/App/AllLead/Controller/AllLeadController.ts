﻿module GCPL.Controller {
    import app = GCPL.app;
    export class AllLeadController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("AllLeadController", AllLeadController);
}