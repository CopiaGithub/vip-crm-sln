﻿module GCPL.Controller {
    import app = GCPL.app;
    export class LeadOverrideResubmitController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("LeadOverrideResubmitController", LeadOverrideResubmitController);
}