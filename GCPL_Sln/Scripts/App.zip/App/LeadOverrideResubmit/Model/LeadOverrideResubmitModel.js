var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var EditLeadOverrideModel = /** @class */ (function () {
            function EditLeadOverrideModel() {
            }
            return EditLeadOverrideModel;
        }());
        Model.EditLeadOverrideModel = EditLeadOverrideModel;
        var SearchRefUserModel = /** @class */ (function () {
            function SearchRefUserModel() {
            }
            return SearchRefUserModel;
        }());
        Model.SearchRefUserModel = SearchRefUserModel;
        var GetSalesAreaModel = /** @class */ (function () {
            function GetSalesAreaModel() {
            }
            return GetSalesAreaModel;
        }());
        Model.GetSalesAreaModel = GetSalesAreaModel;
        var CheckSalesAreaModel = /** @class */ (function () {
            function CheckSalesAreaModel() {
            }
            return CheckSalesAreaModel;
        }());
        Model.CheckSalesAreaModel = CheckSalesAreaModel;
        var RegionCheckModel = /** @class */ (function () {
            function RegionCheckModel() {
            }
            return RegionCheckModel;
        }());
        Model.RegionCheckModel = RegionCheckModel;
        var InsertRegionModel = /** @class */ (function () {
            function InsertRegionModel() {
            }
            return InsertRegionModel;
        }());
        Model.InsertRegionModel = InsertRegionModel;
        var ReasonForLeadDDModel = /** @class */ (function () {
            function ReasonForLeadDDModel() {
            }
            return ReasonForLeadDDModel;
        }());
        Model.ReasonForLeadDDModel = ReasonForLeadDDModel;
        var LeadStatusForCloserDDModel = /** @class */ (function () {
            function LeadStatusForCloserDDModel() {
            }
            return LeadStatusForCloserDDModel;
        }());
        Model.LeadStatusForCloserDDModel = LeadStatusForCloserDDModel;
        //export class SalesAreaModel {
        //    constructor() { }
        //    SalesAreaID: number;
        //}
        var UpdateLeadOverrideModel = /** @class */ (function () {
            function UpdateLeadOverrideModel() {
            }
            return UpdateLeadOverrideModel;
        }());
        Model.UpdateLeadOverrideModel = UpdateLeadOverrideModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadOverrideResubmitModel.js.map