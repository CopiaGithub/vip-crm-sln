﻿module GCPL.Controller {
    import app = GCPL.app;
    export class FaultyLeadController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("FaultyLeadController", FaultyLeadController);
}