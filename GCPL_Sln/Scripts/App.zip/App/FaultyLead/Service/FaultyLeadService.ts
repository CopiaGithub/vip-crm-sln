﻿namespace GCPL.Service {
    import app = GCPL.app;
    import model = GCPL.Model;
}