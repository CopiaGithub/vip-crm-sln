﻿module GCPL.Controller {
    import app = GCPL.app;
    export class CustomerBroadcastMasterController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("CustomerBroadcastMasterController", CustomerBroadcastMasterController);
}