var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var CustomerCastListModel = /** @class */ (function () {
            function CustomerCastListModel() {
            }
            return CustomerCastListModel;
        }());
        Model.CustomerCastListModel = CustomerCastListModel;
        var CustomerCastSearchModel = /** @class */ (function () {
            function CustomerCastSearchModel() {
            }
            return CustomerCastSearchModel;
        }());
        Model.CustomerCastSearchModel = CustomerCastSearchModel;
        var InsertCustomerCastModel = /** @class */ (function () {
            function InsertCustomerCastModel() {
            }
            return InsertCustomerCastModel;
        }());
        Model.InsertCustomerCastModel = InsertCustomerCastModel;
        var EditCustomerCastModel = /** @class */ (function () {
            function EditCustomerCastModel() {
            }
            return EditCustomerCastModel;
        }());
        Model.EditCustomerCastModel = EditCustomerCastModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=CustomerBroadcastMasterModel.js.map