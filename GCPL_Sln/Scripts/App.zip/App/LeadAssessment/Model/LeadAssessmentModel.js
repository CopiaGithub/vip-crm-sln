var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var LeadAssessmentModel = /** @class */ (function () {
            function LeadAssessmentModel() {
            }
            return LeadAssessmentModel;
        }());
        Model.LeadAssessmentModel = LeadAssessmentModel;
        var ValidateContactListModel = /** @class */ (function () {
            function ValidateContactListModel() {
            }
            return ValidateContactListModel;
        }());
        Model.ValidateContactListModel = ValidateContactListModel;
        var LeadAssessmentInfoModel = /** @class */ (function () {
            function LeadAssessmentInfoModel() {
            }
            return LeadAssessmentInfoModel;
        }());
        Model.LeadAssessmentInfoModel = LeadAssessmentInfoModel;
        var CrtAssessmtModel = /** @class */ (function () {
            function CrtAssessmtModel() {
            }
            return CrtAssessmtModel;
        }());
        Model.CrtAssessmtModel = CrtAssessmtModel;
        var UpdateLeadDataModel = /** @class */ (function () {
            function UpdateLeadDataModel() {
            }
            return UpdateLeadDataModel;
        }());
        Model.UpdateLeadDataModel = UpdateLeadDataModel;
        var ReturnModel = /** @class */ (function () {
            function ReturnModel() {
            }
            return ReturnModel;
        }());
        Model.ReturnModel = ReturnModel;
        var InsertLeadActivity = /** @class */ (function () {
            function InsertLeadActivity() {
            }
            return InsertLeadActivity;
        }());
        Model.InsertLeadActivity = InsertLeadActivity;
        var Activity = /** @class */ (function () {
            function Activity() {
            }
            return Activity;
        }());
        Model.Activity = Activity;
        //export class LeadItemCreateModel {
        //    constructor() {
        //    }
        //    ItemID: string;
        //    Status: string;
        //    ProductID: string;
        //    ProductDesc: string;
        //    ModelID: string;
        //    PurchaseTimelineID: string;
        //    IsActive: string;
        //    SalesOfficeID: string;
        //    IndustryDivisionID: string;
        //    IndustrialSegmentID: string;
        //    CategoryID: string;
        //    LeadCategoryID: string;
        //    DivisionID: string;
        //    ChannelID: string;
        //    ItemStatusID: string;
        //    LeadStatusId: string;
        //    ProjectID: string;
        //}
        var LeadItemCreateModel = /** @class */ (function () {
            function LeadItemCreateModel() {
            }
            return LeadItemCreateModel;
        }());
        Model.LeadItemCreateModel = LeadItemCreateModel;
        var EditActivityModel = /** @class */ (function () {
            function EditActivityModel() {
            }
            return EditActivityModel;
        }());
        Model.EditActivityModel = EditActivityModel;
        var LeadActivityModel = /** @class */ (function () {
            function LeadActivityModel() {
            }
            return LeadActivityModel;
        }());
        Model.LeadActivityModel = LeadActivityModel;
        var LeadItemModel = /** @class */ (function () {
            function LeadItemModel() {
            }
            return LeadItemModel;
        }());
        Model.LeadItemModel = LeadItemModel;
        var LeadQueAnsModel = /** @class */ (function () {
            function LeadQueAnsModel() {
            }
            return LeadQueAnsModel;
        }());
        Model.LeadQueAnsModel = LeadQueAnsModel;
        var LeadOpportunityModel = /** @class */ (function () {
            function LeadOpportunityModel() {
            }
            return LeadOpportunityModel;
        }());
        Model.LeadOpportunityModel = LeadOpportunityModel;
        var LeadActivitySearchModel = /** @class */ (function () {
            function LeadActivitySearchModel() {
            }
            return LeadActivitySearchModel;
        }());
        Model.LeadActivitySearchModel = LeadActivitySearchModel;
        var ModeActivityModel = /** @class */ (function () {
            function ModeActivityModel() {
            }
            return ModeActivityModel;
        }());
        Model.ModeActivityModel = ModeActivityModel;
        var LeadActivityStatusModel = /** @class */ (function () {
            function LeadActivityStatusModel() {
            }
            return LeadActivityStatusModel;
        }());
        Model.LeadActivityStatusModel = LeadActivityStatusModel;
        var Ans1DDLModel = /** @class */ (function () {
            function Ans1DDLModel() {
            }
            return Ans1DDLModel;
        }());
        Model.Ans1DDLModel = Ans1DDLModel;
        var Ans2DDLModel = /** @class */ (function () {
            function Ans2DDLModel() {
            }
            return Ans2DDLModel;
        }());
        Model.Ans2DDLModel = Ans2DDLModel;
        var Ans3DDLModel = /** @class */ (function () {
            function Ans3DDLModel() {
            }
            return Ans3DDLModel;
        }());
        Model.Ans3DDLModel = Ans3DDLModel;
        var LeadActivityPurposeModel = /** @class */ (function () {
            function LeadActivityPurposeModel() {
            }
            return LeadActivityPurposeModel;
        }());
        Model.LeadActivityPurposeModel = LeadActivityPurposeModel;
        var LeadActivityLocationModel = /** @class */ (function () {
            function LeadActivityLocationModel() {
            }
            return LeadActivityLocationModel;
        }());
        Model.LeadActivityLocationModel = LeadActivityLocationModel;
        var GetDisqualificationReasonDDModel = /** @class */ (function () {
            function GetDisqualificationReasonDDModel() {
            }
            return GetDisqualificationReasonDDModel;
        }());
        Model.GetDisqualificationReasonDDModel = GetDisqualificationReasonDDModel;
        var SalesStageDDModel = /** @class */ (function () {
            function SalesStageDDModel() {
            }
            return SalesStageDDModel;
        }());
        Model.SalesStageDDModel = SalesStageDDModel;
        var LeadStatusDDModel = /** @class */ (function () {
            function LeadStatusDDModel() {
            }
            return LeadStatusDDModel;
        }());
        Model.LeadStatusDDModel = LeadStatusDDModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadAssessmentModel.js.map