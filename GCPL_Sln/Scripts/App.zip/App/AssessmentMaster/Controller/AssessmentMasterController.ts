﻿module GCPL.Controller {
    import app = GCPL.app;
    export class AssessmentMasterController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("AssessmentMasterController", AssessmentMasterController);
}