﻿module GCPL.Controller {
    import app = GCPL.app;
    export class LeadOverrideController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("LeadOverrideController", LeadOverrideController);
}