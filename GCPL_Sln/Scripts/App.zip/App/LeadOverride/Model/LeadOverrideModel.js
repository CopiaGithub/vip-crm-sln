var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        //search
        var LeadOverrideListModel = /** @class */ (function () {
            function LeadOverrideListModel() {
            }
            return LeadOverrideListModel;
        }());
        Model.LeadOverrideListModel = LeadOverrideListModel;
        var LeadOverrideSearchModel = /** @class */ (function () {
            function LeadOverrideSearchModel() {
            }
            return LeadOverrideSearchModel;
        }());
        Model.LeadOverrideSearchModel = LeadOverrideSearchModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadOverrideModel.js.map