var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var LeadDashSearchModel = /** @class */ (function () {
            function LeadDashSearchModel() {
            }
            return LeadDashSearchModel;
        }());
        Model.LeadDashSearchModel = LeadDashSearchModel;
        var LeadSnapshotModel = /** @class */ (function () {
            function LeadSnapshotModel() {
            }
            return LeadSnapshotModel;
        }());
        Model.LeadSnapshotModel = LeadSnapshotModel;
        var LeadDashListModel = /** @class */ (function () {
            function LeadDashListModel() {
            }
            return LeadDashListModel;
        }());
        Model.LeadDashListModel = LeadDashListModel;
        var DivisionPieModel = /** @class */ (function () {
            function DivisionPieModel() {
            }
            return DivisionPieModel;
        }());
        Model.DivisionPieModel = DivisionPieModel;
        var RegionPieModel = /** @class */ (function () {
            function RegionPieModel() {
            }
            return RegionPieModel;
        }());
        Model.RegionPieModel = RegionPieModel;
        var ZonePieModel = /** @class */ (function () {
            function ZonePieModel() {
            }
            return ZonePieModel;
        }());
        Model.ZonePieModel = ZonePieModel;
        var ProductPieModel = /** @class */ (function () {
            function ProductPieModel() {
            }
            return ProductPieModel;
        }());
        Model.ProductPieModel = ProductPieModel;
        var StatePieModel = /** @class */ (function () {
            function StatePieModel() {
            }
            return StatePieModel;
        }());
        Model.StatePieModel = StatePieModel;
        var LeadDashSearchDataModel = /** @class */ (function () {
            function LeadDashSearchDataModel() {
            }
            return LeadDashSearchDataModel;
        }());
        Model.LeadDashSearchDataModel = LeadDashSearchDataModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadDashboardModel.js.map