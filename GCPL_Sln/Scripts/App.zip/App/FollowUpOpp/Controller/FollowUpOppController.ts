﻿module GCPL.Controller {
    import app = GCPL.app;
    export class FollowUpOppController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("FollowUpOppController", FollowUpOppController);

}