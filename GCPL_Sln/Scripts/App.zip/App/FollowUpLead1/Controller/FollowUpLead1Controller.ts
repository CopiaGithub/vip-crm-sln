﻿module GCPL.Controller {
    import app = GCPL.app;
    export class FollowUpLead1Controller extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("FollowUpLead1Controller", FollowUpLead1Controller);

}