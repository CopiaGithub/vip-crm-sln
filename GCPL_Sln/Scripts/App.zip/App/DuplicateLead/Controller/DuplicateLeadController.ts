﻿module GCPL.Controller {
    import app = GCPL.app;
    export class DuplicateLeadController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("DuplicateLeadController", DuplicateLeadController);
}