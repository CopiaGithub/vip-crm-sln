var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var LeadsMTTRHeaderModel = /** @class */ (function () {
            function LeadsMTTRHeaderModel() {
            }
            return LeadsMTTRHeaderModel;
        }());
        Model.LeadsMTTRHeaderModel = LeadsMTTRHeaderModel;
        var LeadsMTTRGridModel = /** @class */ (function () {
            function LeadsMTTRGridModel() {
            }
            return LeadsMTTRGridModel;
        }());
        Model.LeadsMTTRGridModel = LeadsMTTRGridModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadMTTRReportModel.js.map