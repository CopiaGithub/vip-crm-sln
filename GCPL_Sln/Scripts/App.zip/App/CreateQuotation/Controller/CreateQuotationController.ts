﻿module GCPL.Controller {
    import app = GCPL.app;
    export class CreateQuotationController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("CreateQuotationController", CreateQuotationController);
}