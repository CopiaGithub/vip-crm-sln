var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var Accessory1ddlModel = /** @class */ (function () {
            function Accessory1ddlModel() {
            }
            return Accessory1ddlModel;
        }());
        Model.Accessory1ddlModel = Accessory1ddlModel;
        var Option1ddlModel = /** @class */ (function () {
            function Option1ddlModel() {
            }
            return Option1ddlModel;
        }());
        Model.Option1ddlModel = Option1ddlModel;
        var Accessory2ddlModel = /** @class */ (function () {
            function Accessory2ddlModel() {
            }
            return Accessory2ddlModel;
        }());
        Model.Accessory2ddlModel = Accessory2ddlModel;
        var Option2ddlModel = /** @class */ (function () {
            function Option2ddlModel() {
            }
            return Option2ddlModel;
        }());
        Model.Option2ddlModel = Option2ddlModel;
        var Accessory3ddlModel = /** @class */ (function () {
            function Accessory3ddlModel() {
            }
            return Accessory3ddlModel;
        }());
        Model.Accessory3ddlModel = Accessory3ddlModel;
        var Option3ddlModel = /** @class */ (function () {
            function Option3ddlModel() {
            }
            return Option3ddlModel;
        }());
        Model.Option3ddlModel = Option3ddlModel;
        var Accessory4ddlModel = /** @class */ (function () {
            function Accessory4ddlModel() {
            }
            return Accessory4ddlModel;
        }());
        Model.Accessory4ddlModel = Accessory4ddlModel;
        var Option4ddlModel = /** @class */ (function () {
            function Option4ddlModel() {
            }
            return Option4ddlModel;
        }());
        Model.Option4ddlModel = Option4ddlModel;
        var Accessory5ddlModel = /** @class */ (function () {
            function Accessory5ddlModel() {
            }
            return Accessory5ddlModel;
        }());
        Model.Accessory5ddlModel = Accessory5ddlModel;
        var Option5ddlModel = /** @class */ (function () {
            function Option5ddlModel() {
            }
            return Option5ddlModel;
        }());
        Model.Option5ddlModel = Option5ddlModel;
        var Accessory6ddlModel = /** @class */ (function () {
            function Accessory6ddlModel() {
            }
            return Accessory6ddlModel;
        }());
        Model.Accessory6ddlModel = Accessory6ddlModel;
        var Option6ddlModel = /** @class */ (function () {
            function Option6ddlModel() {
            }
            return Option6ddlModel;
        }());
        Model.Option6ddlModel = Option6ddlModel;
        var Config1ddlModel = /** @class */ (function () {
            function Config1ddlModel() {
            }
            return Config1ddlModel;
        }());
        Model.Config1ddlModel = Config1ddlModel;
        var Config2ddlModel = /** @class */ (function () {
            function Config2ddlModel() {
            }
            return Config2ddlModel;
        }());
        Model.Config2ddlModel = Config2ddlModel;
        var SOSModel = /** @class */ (function () {
            function SOSModel() {
            }
            return SOSModel;
        }());
        Model.SOSModel = SOSModel;
        var InsertQuotationModel = /** @class */ (function () {
            function InsertQuotationModel() {
            }
            return InsertQuotationModel;
        }());
        Model.InsertQuotationModel = InsertQuotationModel;
        var COLModel = /** @class */ (function () {
            function COLModel() {
            }
            return COLModel;
        }());
        Model.COLModel = COLModel;
        var ProductFModel = /** @class */ (function () {
            function ProductFModel() {
            }
            return ProductFModel;
        }());
        Model.ProductFModel = ProductFModel;
        var ProdFModel = /** @class */ (function () {
            function ProdFModel() {
            }
            return ProdFModel;
        }());
        Model.ProdFModel = ProdFModel;
        var TermsCModel = /** @class */ (function () {
            function TermsCModel() {
            }
            return TermsCModel;
        }());
        Model.TermsCModel = TermsCModel;
        var OfferModel = /** @class */ (function () {
            function OfferModel() {
            }
            return OfferModel;
        }());
        Model.OfferModel = OfferModel;
        var CapabilityModel = /** @class */ (function () {
            function CapabilityModel() {
            }
            return CapabilityModel;
        }());
        Model.CapabilityModel = CapabilityModel;
        var TotalPriceModel = /** @class */ (function () {
            function TotalPriceModel() {
            }
            return TotalPriceModel;
        }());
        Model.TotalPriceModel = TotalPriceModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=CreateQuotationModel.js.map