var GCPL;
(function (GCPL) {
    var Costant;
    (function (Costant) {
        var ApiEndPoint = /** @class */ (function () {
            function ApiEndPoint() {
            }
            ApiEndPoint.BaseUrl = "";
            return ApiEndPoint;
        }());
        Costant.ApiEndPoint = ApiEndPoint;
        var CookieConstant = /** @class */ (function () {
            function CookieConstant() {
            }
            CookieConstant.UserInfo = "UserInfo";
            return CookieConstant;
        }());
        Costant.CookieConstant = CookieConstant;
    })(Costant = GCPL.Costant || (GCPL.Costant = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=Constatnt.js.map