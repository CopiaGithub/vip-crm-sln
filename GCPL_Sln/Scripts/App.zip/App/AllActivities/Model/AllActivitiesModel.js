var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var AllActModel = /** @class */ (function () {
            function AllActModel() {
            }
            return AllActModel;
        }());
        Model.AllActModel = AllActModel;
        var AllActSearchModel = /** @class */ (function () {
            function AllActSearchModel() {
            }
            return AllActSearchModel;
        }());
        Model.AllActSearchModel = AllActSearchModel;
        var AllActSAPSearchModel = /** @class */ (function () {
            function AllActSAPSearchModel() {
            }
            return AllActSAPSearchModel;
        }());
        Model.AllActSAPSearchModel = AllActSAPSearchModel;
        //export class InsertActModel {
        //    constructor() {
        //    }
        //    actid: string;
        //    custid: string;           //BusinessPartnerNo
        //    conid: string;            //SAPID
        //    ptype: string;           //ActivityType
        //    date: string;
        //    cate: string;             //Category
        //    ActivityStatus: string;  //Activity Status
        //    purid: string;            //Purpose
        //    loc: string;             //Location
        //    note: string;            //Note comment
        //    erpid: string;            //EmployeeCode
        //    ftime: string;           //"141516"
        //    ttime: string;           //"101010"
        //    sorg: string;           //"O 50000002"
        //    sofc: string;           //"SOFF1001"
        //    dchnl: string;         //"10"
        //    div: string;            //"20"
        //    reftyp: string;         //Null
        //    refid: string;           //Null
        //    lat: string;            //"0"
        //    location: string;       //Null
        //    agnst: string;          //Null
        //    ltter: string;         //Null
        //    UserID: string;        //Null
        //    CustomerID: string;    //CustomerID
        //    ContactID: string;     //ContactId
        //}
        var EditAllActModel = /** @class */ (function () {
            function EditAllActModel() {
            }
            return EditAllActModel;
        }());
        Model.EditAllActModel = EditAllActModel;
        //export class UserInfoModel {
        //    constructor() {
        //    }
        //    UserID: string;
        //    EmployeeCode: string;
        //    SalesOfficeID: string;
        //}
        //export class ActivityType {
        //    constructor() {
        //    }
        //    PurposeID: string;
        //    Purpose: string;
        //    IsActive: string;
        //}
        //export class EditContact {
        //    constructor() {
        //    }
        //    ContactID: string;
        //    ContactName: string;
        //    ContactMobileNo: string;
        //    ContactSAPID: string;
        //    FOP: string;
        //}
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=AllActivitiesModel.js.map