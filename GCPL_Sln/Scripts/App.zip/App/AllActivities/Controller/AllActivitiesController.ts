﻿
module GCPL.Controller {
    import app = GCPL.app;
    export class AllActivitiesController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("AllActivitiesController", AllActivitiesController);
}