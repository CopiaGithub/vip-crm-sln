var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var EmployeeCastListModel = /** @class */ (function () {
            function EmployeeCastListModel() {
            }
            return EmployeeCastListModel;
        }());
        Model.EmployeeCastListModel = EmployeeCastListModel;
        var EmployeeCastSearchModel = /** @class */ (function () {
            function EmployeeCastSearchModel() {
            }
            return EmployeeCastSearchModel;
        }());
        Model.EmployeeCastSearchModel = EmployeeCastSearchModel;
        var InsertEmployeeCastModel = /** @class */ (function () {
            function InsertEmployeeCastModel() {
            }
            return InsertEmployeeCastModel;
        }());
        Model.InsertEmployeeCastModel = InsertEmployeeCastModel;
        var EditEmployeeCastModel = /** @class */ (function () {
            function EditEmployeeCastModel() {
            }
            return EditEmployeeCastModel;
        }());
        Model.EditEmployeeCastModel = EditEmployeeCastModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=EmployeeBroadcastMasterModel.js.map