﻿module GCPL.Controller {
    import app = GCPL.app;
    export class EmployeeBroadcastMasterController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("EmployeeBroadcastMasterController", EmployeeBroadcastMasterController);
}