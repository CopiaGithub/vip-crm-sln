var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var LeadSummaryListModel = /** @class */ (function () {
            function LeadSummaryListModel() {
            }
            return LeadSummaryListModel;
        }());
        Model.LeadSummaryListModel = LeadSummaryListModel;
        var InsertLeadSummModel = /** @class */ (function () {
            function InsertLeadSummModel() {
            }
            return InsertLeadSummModel;
        }());
        Model.InsertLeadSummModel = InsertLeadSummModel;
        var EditLeadSummlistModel = /** @class */ (function () {
            function EditLeadSummlistModel() {
            }
            return EditLeadSummlistModel;
        }());
        Model.EditLeadSummlistModel = EditLeadSummlistModel;
        var ModeldModel = /** @class */ (function () {
            function ModeldModel() {
            }
            return ModeldModel;
        }());
        Model.ModeldModel = ModeldModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadSummaryEmailsModel.js.map