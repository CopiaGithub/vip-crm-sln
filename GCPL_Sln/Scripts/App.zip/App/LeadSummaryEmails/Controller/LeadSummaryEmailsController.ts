﻿module GCPL.Controller {
    import app = GCPL.app;
    export class LeadSummaryEmailsController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("LeadSummaryEmailsController", LeadSummaryEmailsController);
}