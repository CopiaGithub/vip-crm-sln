var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var DeliveryScheduleModel = /** @class */ (function () {
            function DeliveryScheduleModel() {
            }
            return DeliveryScheduleModel;
        }());
        Model.DeliveryScheduleModel = DeliveryScheduleModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=DeliveryScheduleModel.js.map