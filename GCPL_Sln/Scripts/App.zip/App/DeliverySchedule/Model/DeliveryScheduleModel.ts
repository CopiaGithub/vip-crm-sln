﻿namespace GCPL.Model {
    export class DeliveryScheduleModel {
        constructor() {
        }
        ID: string;
        ItemID: string;
        ProductID: string;
        ProductCode: string;
        ProductDesc: string;
        UserID: string;
        LeadID: string;
        DeliveryDate: string;
        DeliveryQty: string;
        EditState: string;
    }
}


