﻿module GCPL.Controller {
    import app = GCPL.app;
    export class DeliveryScheduleController extends GCPL.Controller.CoockiesBaseController {

    }


    app.AddController("DeliveryScheduleController", DeliveryScheduleController);
}