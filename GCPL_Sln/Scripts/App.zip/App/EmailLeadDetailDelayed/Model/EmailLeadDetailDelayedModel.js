var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var EmailLeadListModel = /** @class */ (function () {
            function EmailLeadListModel() {
            }
            return EmailLeadListModel;
        }());
        Model.EmailLeadListModel = EmailLeadListModel;
        var InsertEmailLeadModel = /** @class */ (function () {
            function InsertEmailLeadModel() {
            }
            return InsertEmailLeadModel;
        }());
        Model.InsertEmailLeadModel = InsertEmailLeadModel;
        var EditEmailLeadListModel = /** @class */ (function () {
            function EditEmailLeadListModel() {
            }
            return EditEmailLeadListModel;
        }());
        Model.EditEmailLeadListModel = EditEmailLeadListModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=EmailLeadDetailDelayedModel.js.map