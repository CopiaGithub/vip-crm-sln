﻿module GCPL.Controller {
    import app = GCPL.app;
    export class EmailLeadDetailDelayedController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("EmailLeadDetailDelayedController", EmailLeadDetailDelayedController);
}