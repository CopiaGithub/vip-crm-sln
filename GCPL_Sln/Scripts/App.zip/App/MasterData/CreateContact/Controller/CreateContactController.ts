﻿module GCPL.Controller {
    import app = GCPL.app;
    export class CreateContactController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("CreateContactController", CreateContactController);
}