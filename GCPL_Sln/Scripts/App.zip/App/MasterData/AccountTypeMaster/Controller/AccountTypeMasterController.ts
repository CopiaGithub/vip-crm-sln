﻿module GCPL.Controller {
    import app = GCPL.app;
    export class AccountTypeMasterController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("AccountTypeMasterController", AccountTypeMasterController);
}