var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var AccountTypeListModel = /** @class */ (function () {
            function AccountTypeListModel() {
            }
            return AccountTypeListModel;
        }());
        Model.AccountTypeListModel = AccountTypeListModel;
        var AccountSearchModel = /** @class */ (function () {
            function AccountSearchModel() {
            }
            return AccountSearchModel;
        }());
        Model.AccountSearchModel = AccountSearchModel;
        var InsertAccountModel = /** @class */ (function () {
            function InsertAccountModel() {
            }
            return InsertAccountModel;
        }());
        Model.InsertAccountModel = InsertAccountModel;
        var EditAccountlistModel = /** @class */ (function () {
            function EditAccountlistModel() {
            }
            return EditAccountlistModel;
        }());
        Model.EditAccountlistModel = EditAccountlistModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=AccountTypeMasterModel.js.map