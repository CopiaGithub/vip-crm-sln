var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var ContactListModel = /** @class */ (function () {
            function ContactListModel() {
            }
            return ContactListModel;
        }());
        Model.ContactListModel = ContactListModel;
        var ContactSearchModel = /** @class */ (function () {
            function ContactSearchModel() {
            }
            return ContactSearchModel;
        }());
        Model.ContactSearchModel = ContactSearchModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=ContactMasterModel.js.map