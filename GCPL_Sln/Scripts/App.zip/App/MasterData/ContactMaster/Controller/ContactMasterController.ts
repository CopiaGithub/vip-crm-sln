﻿module GCPL.Controller {
    import app = GCPL.app;
    export class ContactMasterController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("ContactMasterController", ContactMasterController);
}