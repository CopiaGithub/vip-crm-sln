var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var CatlistModel = /** @class */ (function () {
            function CatlistModel() {
            }
            return CatlistModel;
        }());
        Model.CatlistModel = CatlistModel;
        var CategorySearchModel = /** @class */ (function () {
            function CategorySearchModel() {
            }
            return CategorySearchModel;
        }());
        Model.CategorySearchModel = CategorySearchModel;
        var InsertCategoryModel = /** @class */ (function () {
            function InsertCategoryModel() {
            }
            return InsertCategoryModel;
        }());
        Model.InsertCategoryModel = InsertCategoryModel;
        var EditCatlistModel = /** @class */ (function () {
            function EditCatlistModel() {
            }
            return EditCatlistModel;
        }());
        Model.EditCatlistModel = EditCatlistModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=CategoryMasterModel.js.map