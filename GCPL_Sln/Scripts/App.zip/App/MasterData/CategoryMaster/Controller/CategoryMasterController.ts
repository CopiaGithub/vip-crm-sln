﻿
module GCPL.Controller {
    import app = GCPL.app;
    export class CategoryMasterController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("CategoryMasterController", CategoryMasterController);
}