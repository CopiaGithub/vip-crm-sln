﻿module GCPL.Controller {
    import app = GCPL.app;
    export class CampaignLeadsController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("CampaignLeadsController", CampaignLeadsController);
}