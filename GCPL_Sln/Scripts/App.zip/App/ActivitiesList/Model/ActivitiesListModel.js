var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var ActlistModel = /** @class */ (function () {
            function ActlistModel() {
            }
            return ActlistModel;
        }());
        Model.ActlistModel = ActlistModel;
        var ContactDetailsListModel = /** @class */ (function () {
            function ContactDetailsListModel() {
            }
            return ContactDetailsListModel;
        }());
        Model.ContactDetailsListModel = ContactDetailsListModel;
        var ActSearchModel = /** @class */ (function () {
            function ActSearchModel() {
            }
            return ActSearchModel;
        }());
        Model.ActSearchModel = ActSearchModel;
        var ActSAPSearchModel = /** @class */ (function () {
            function ActSAPSearchModel() {
            }
            return ActSAPSearchModel;
        }());
        Model.ActSAPSearchModel = ActSAPSearchModel;
        var InsertActModel = /** @class */ (function () {
            function InsertActModel() {
            }
            return InsertActModel;
        }());
        Model.InsertActModel = InsertActModel;
        var EditActlistModel = /** @class */ (function () {
            function EditActlistModel() {
            }
            return EditActlistModel;
        }());
        Model.EditActlistModel = EditActlistModel;
        var UserInfoModel = /** @class */ (function () {
            function UserInfoModel() {
            }
            return UserInfoModel;
        }());
        Model.UserInfoModel = UserInfoModel;
        var ActivityType = /** @class */ (function () {
            function ActivityType() {
            }
            return ActivityType;
        }());
        Model.ActivityType = ActivityType;
        var EditContact = /** @class */ (function () {
            function EditContact() {
            }
            return EditContact;
        }());
        Model.EditContact = EditContact;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=ActivitiesListModel.js.map