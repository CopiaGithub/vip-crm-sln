﻿
module GCPL.Controller {
    import app = GCPL.app;
    export class ActivitiesListController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("ActivitiesListController", ActivitiesListController);
}