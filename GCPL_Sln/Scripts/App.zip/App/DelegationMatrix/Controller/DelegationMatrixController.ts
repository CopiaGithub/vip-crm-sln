﻿module GCPL.Controller {
    import app = GCPL.app;
    export class DelegationMatrixController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("DelegationMatrixController", DelegationMatrixController);
}