var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var DeligationMasterGridModel = /** @class */ (function () {
            function DeligationMasterGridModel() {
            }
            return DeligationMasterGridModel;
        }());
        Model.DeligationMasterGridModel = DeligationMasterGridModel;
        var DeligationMasterHeaderModel = /** @class */ (function () {
            function DeligationMasterHeaderModel() {
            }
            return DeligationMasterHeaderModel;
        }());
        Model.DeligationMasterHeaderModel = DeligationMasterHeaderModel;
        var DeligationMasterInsertModel = /** @class */ (function () {
            function DeligationMasterInsertModel() {
            }
            return DeligationMasterInsertModel;
        }());
        Model.DeligationMasterInsertModel = DeligationMasterInsertModel;
        var DeligationMasterEditModel = /** @class */ (function () {
            function DeligationMasterEditModel() {
            }
            return DeligationMasterEditModel;
        }());
        Model.DeligationMasterEditModel = DeligationMasterEditModel;
        var ManagerAutofill = /** @class */ (function () {
            function ManagerAutofill() {
            }
            return ManagerAutofill;
        }());
        Model.ManagerAutofill = ManagerAutofill;
        var EmployeeAutofill = /** @class */ (function () {
            function EmployeeAutofill() {
            }
            return EmployeeAutofill;
        }());
        Model.EmployeeAutofill = EmployeeAutofill;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=DelegationMatrixModel.js.map