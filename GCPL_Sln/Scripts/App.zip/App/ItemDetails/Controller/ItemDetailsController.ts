﻿module GCPL.Controller {
    import app = GCPL.app;
    export class ItemDetailsController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("ItemDetailsController", ItemDetailsController);
}