﻿module GCPL.Controller {
    import app = GCPL.app;
    export class CalendarPageController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("CalendarPageController", CalendarPageController);
}