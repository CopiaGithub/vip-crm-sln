﻿namespace GCPL.Model {
    export class GetCalDeligDDlModel {
        constructor() {
        }
        ManagerCode: string;
        EmployeeName: string;
    }

    export class CalActlistModel {
        constructor() {
        }
        //ActivityID: string;
        //CustomerID: string;
        //CompanyName: string;
        //CustomerSAPID: string;
        //ContactID: string;
        //ContactName: string;
        //ContactSAPID: string;
        //Note: string;
        //ActivityName: string;
        ActivityDate: string;
        Status: string;
       // IsActive: string;
        //Purpose: string;
        //Mode: string;
        //Location: string;
        //ReferenceType: string;
        //ReferenceLead: string;
        //ReferenceOpportunity: string;
        //StartDate: string;
        //EndDate: string;
        ActivityNumber: string;
        color: string;
        ManagerCode: string;
        WhenEntered: string;
    }

    export class CalActSearchModel {
        constructor() {
        }
        UserID: string;
    }

    export class delgSearchddlModel {
        constructor() {
        }
        ManagerCode: string;
    }
}