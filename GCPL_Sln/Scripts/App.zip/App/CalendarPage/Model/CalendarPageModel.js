var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var GetCalDeligDDlModel = /** @class */ (function () {
            function GetCalDeligDDlModel() {
            }
            return GetCalDeligDDlModel;
        }());
        Model.GetCalDeligDDlModel = GetCalDeligDDlModel;
        var CalActlistModel = /** @class */ (function () {
            function CalActlistModel() {
            }
            return CalActlistModel;
        }());
        Model.CalActlistModel = CalActlistModel;
        var CalActSearchModel = /** @class */ (function () {
            function CalActSearchModel() {
            }
            return CalActSearchModel;
        }());
        Model.CalActSearchModel = CalActSearchModel;
        var delgSearchddlModel = /** @class */ (function () {
            function delgSearchddlModel() {
            }
            return delgSearchddlModel;
        }());
        Model.delgSearchddlModel = delgSearchddlModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=CalendarPageModel.js.map