﻿module GCPL.Costant {
    export class ApiEndPoint {
        static BaseUrl = "";
    }

    export class CookieConstant {
        static UserInfo = "UserInfo";
    }
}