﻿module GCPL.Controller {
    import app = GCPL.app;
    export class ManagerDashboardController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("ManagerDashboardController", ManagerDashboardController);
}