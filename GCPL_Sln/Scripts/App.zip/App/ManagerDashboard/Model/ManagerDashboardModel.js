var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var LeadCountModel = /** @class */ (function () {
            function LeadCountModel() {
            }
            return LeadCountModel;
        }());
        Model.LeadCountModel = LeadCountModel;
        var OpportunityCountModel = /** @class */ (function () {
            function OpportunityCountModel() {
            }
            return OpportunityCountModel;
        }());
        Model.OpportunityCountModel = OpportunityCountModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=ManagerDashboardModel.js.map