var GCPL;
(function (GCPL) {
    var Controller;
    (function (Controller) {
        var app = GCPL.app;
        var LoginPageController = /** @class */ (function () {
            function LoginPageController() {
                console.log("LoginPageController initialized...");
            }
            return LoginPageController;
        }());
        Controller.LoginPageController = LoginPageController;
        app.AddController("LoginPageController", LoginPageController);
    })(Controller = GCPL.Controller || (GCPL.Controller = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LoginPageController.js.map