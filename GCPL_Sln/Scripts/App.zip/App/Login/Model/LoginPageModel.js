var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var ILoginPut = /** @class */ (function () {
            function ILoginPut() {
            }
            return ILoginPut;
        }());
        Model.ILoginPut = ILoginPut;
        var ILoginResponse = /** @class */ (function () {
            function ILoginResponse() {
            }
            return ILoginResponse;
        }());
        Model.ILoginResponse = ILoginResponse;
        var ICRMLoginResponse = /** @class */ (function () {
            function ICRMLoginResponse() {
            }
            return ICRMLoginResponse;
        }());
        Model.ICRMLoginResponse = ICRMLoginResponse;
        var IGetOTPResponse = /** @class */ (function () {
            function IGetOTPResponse() {
            }
            return IGetOTPResponse;
        }());
        Model.IGetOTPResponse = IGetOTPResponse;
        var IGetValidCRMResponse = /** @class */ (function () {
            function IGetValidCRMResponse() {
            }
            return IGetValidCRMResponse;
        }());
        Model.IGetValidCRMResponse = IGetValidCRMResponse;
        var GetCRMUserModel = /** @class */ (function () {
            function GetCRMUserModel() {
            }
            return GetCRMUserModel;
        }());
        Model.GetCRMUserModel = GetCRMUserModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LoginPageModel.js.map