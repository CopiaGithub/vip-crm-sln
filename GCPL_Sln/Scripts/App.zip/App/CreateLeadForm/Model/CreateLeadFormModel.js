var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var LeadSourceDetailsModel = /** @class */ (function () {
            function LeadSourceDetailsModel() {
            }
            return LeadSourceDetailsModel;
        }());
        Model.LeadSourceDetailsModel = LeadSourceDetailsModel;
        var LeadCatergoryWPModel = /** @class */ (function () {
            function LeadCatergoryWPModel() {
            }
            return LeadCatergoryWPModel;
        }());
        Model.LeadCatergoryWPModel = LeadCatergoryWPModel;
        var ContactInfoModel = /** @class */ (function () {
            function ContactInfoModel() {
            }
            return ContactInfoModel;
        }());
        Model.ContactInfoModel = ContactInfoModel;
        var InsertSubmitModel = /** @class */ (function () {
            function InsertSubmitModel() {
            }
            return InsertSubmitModel;
        }());
        Model.InsertSubmitModel = InsertSubmitModel;
        var ReferredEmpModel = /** @class */ (function () {
            function ReferredEmpModel() {
            }
            return ReferredEmpModel;
        }());
        Model.ReferredEmpModel = ReferredEmpModel;
        var CampaignDetailsModel = /** @class */ (function () {
            function CampaignDetailsModel() {
            }
            return CampaignDetailsModel;
        }());
        Model.CampaignDetailsModel = CampaignDetailsModel;
        var InsertLeadModel = /** @class */ (function () {
            function InsertLeadModel() {
            }
            return InsertLeadModel;
        }());
        Model.InsertLeadModel = InsertLeadModel;
        var AddToCartModel = /** @class */ (function () {
            function AddToCartModel() {
            }
            return AddToCartModel;
        }());
        Model.AddToCartModel = AddToCartModel;
        var PurchaseTimelineModel = /** @class */ (function () {
            function PurchaseTimelineModel() {
            }
            return PurchaseTimelineModel;
        }());
        Model.PurchaseTimelineModel = PurchaseTimelineModel;
        var LeadCustomerListModel = /** @class */ (function () {
            function LeadCustomerListModel() {
            }
            return LeadCustomerListModel;
        }());
        Model.LeadCustomerListModel = LeadCustomerListModel;
        var LeadContactListModel = /** @class */ (function () {
            function LeadContactListModel() {
            }
            return LeadContactListModel;
        }());
        Model.LeadContactListModel = LeadContactListModel;
        var ContactDetailsModel = /** @class */ (function () {
            function ContactDetailsModel() {
            }
            return ContactDetailsModel;
        }());
        Model.ContactDetailsModel = ContactDetailsModel;
        var GetCustomerModel = /** @class */ (function () {
            function GetCustomerModel() {
            }
            return GetCustomerModel;
        }());
        Model.GetCustomerModel = GetCustomerModel;
        var CustomerHeader = /** @class */ (function () {
            function CustomerHeader() {
            }
            return CustomerHeader;
        }());
        Model.CustomerHeader = CustomerHeader;
        var GetCustomerNewModel = /** @class */ (function () {
            function GetCustomerNewModel() {
            }
            return GetCustomerNewModel;
        }());
        Model.GetCustomerNewModel = GetCustomerNewModel;
        var LeadDetailsListModel = /** @class */ (function () {
            function LeadDetailsListModel() {
            }
            return LeadDetailsListModel;
        }());
        Model.LeadDetailsListModel = LeadDetailsListModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=CreateLeadFormModel.js.map