var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var ActivityOverrideListModel = /** @class */ (function () {
            function ActivityOverrideListModel() {
            }
            return ActivityOverrideListModel;
        }());
        Model.ActivityOverrideListModel = ActivityOverrideListModel;
        var ActivityOverrideListDetailsModel = /** @class */ (function () {
            function ActivityOverrideListDetailsModel() {
            }
            return ActivityOverrideListDetailsModel;
        }());
        Model.ActivityOverrideListDetailsModel = ActivityOverrideListDetailsModel;
        var ActivityOverrideSearchModel = /** @class */ (function () {
            function ActivityOverrideSearchModel() {
            }
            return ActivityOverrideSearchModel;
        }());
        Model.ActivityOverrideSearchModel = ActivityOverrideSearchModel;
        var InsertActivityOverrideModel = /** @class */ (function () {
            function InsertActivityOverrideModel() {
            }
            return InsertActivityOverrideModel;
        }());
        Model.InsertActivityOverrideModel = InsertActivityOverrideModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=ActivityOverrideModel.js.map