﻿module GCPL.Controller {
    import app = GCPL.app;
    export class CreateProjectController extends GCPL.Controller.CoockiesBaseController {

    }


    app.AddController("CreateProjectController", CreateProjectController);
}