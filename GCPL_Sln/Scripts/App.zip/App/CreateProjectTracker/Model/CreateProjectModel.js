var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var CreateNewProject = /** @class */ (function () {
            function CreateNewProject() {
            }
            return CreateNewProject;
        }());
        Model.CreateNewProject = CreateNewProject;
        var GetProjectTypeDDModel = /** @class */ (function () {
            function GetProjectTypeDDModel() {
            }
            return GetProjectTypeDDModel;
        }());
        Model.GetProjectTypeDDModel = GetProjectTypeDDModel;
        var UserMasterddlModel = /** @class */ (function () {
            function UserMasterddlModel() {
            }
            return UserMasterddlModel;
        }());
        Model.UserMasterddlModel = UserMasterddlModel;
        var GetCustProjectTypeDDModel = /** @class */ (function () {
            function GetCustProjectTypeDDModel() {
            }
            return GetCustProjectTypeDDModel;
        }());
        Model.GetCustProjectTypeDDModel = GetCustProjectTypeDDModel;
        var GetAddCustProjectTypeDDModel = /** @class */ (function () {
            function GetAddCustProjectTypeDDModel() {
            }
            return GetAddCustProjectTypeDDModel;
        }());
        Model.GetAddCustProjectTypeDDModel = GetAddCustProjectTypeDDModel;
        var GetProjectStageDDModel = /** @class */ (function () {
            function GetProjectStageDDModel() {
            }
            return GetProjectStageDDModel;
        }());
        Model.GetProjectStageDDModel = GetProjectStageDDModel;
        var GetIndustryDDModel = /** @class */ (function () {
            function GetIndustryDDModel() {
            }
            return GetIndustryDDModel;
        }());
        Model.GetIndustryDDModel = GetIndustryDDModel;
        var GetOwnershipModel = /** @class */ (function () {
            function GetOwnershipModel() {
            }
            return GetOwnershipModel;
        }());
        Model.GetOwnershipModel = GetOwnershipModel;
        var GetProjectSourceModel = /** @class */ (function () {
            function GetProjectSourceModel() {
            }
            return GetProjectSourceModel;
        }());
        Model.GetProjectSourceModel = GetProjectSourceModel;
        var GetProjectNameDDModel = /** @class */ (function () {
            function GetProjectNameDDModel() {
            }
            return GetProjectNameDDModel;
        }());
        Model.GetProjectNameDDModel = GetProjectNameDDModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=CreateProjectModel.js.map