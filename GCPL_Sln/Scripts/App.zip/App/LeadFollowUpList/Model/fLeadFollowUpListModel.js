var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var FollowupSearchModel = /** @class */ (function () {
            function FollowupSearchModel() {
            }
            return FollowupSearchModel;
        }());
        Model.FollowupSearchModel = FollowupSearchModel;
        var FollowupListModel = /** @class */ (function () {
            function FollowupListModel() {
            }
            return FollowupListModel;
        }());
        Model.FollowupListModel = FollowupListModel;
        var LeadFUQuestionsModel = /** @class */ (function () {
            function LeadFUQuestionsModel() {
            }
            return LeadFUQuestionsModel;
        }());
        Model.LeadFUQuestionsModel = LeadFUQuestionsModel;
        var LeadFUAnswersModel = /** @class */ (function () {
            function LeadFUAnswersModel() {
            }
            return LeadFUAnswersModel;
        }());
        Model.LeadFUAnswersModel = LeadFUAnswersModel;
        var InsertFUQueAnsModel = /** @class */ (function () {
            function InsertFUQueAnsModel() {
            }
            return InsertFUQueAnsModel;
        }());
        Model.InsertFUQueAnsModel = InsertFUQueAnsModel;
        var FolloupHistListModel = /** @class */ (function () {
            function FolloupHistListModel() {
            }
            return FolloupHistListModel;
        }());
        Model.FolloupHistListModel = FolloupHistListModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=fLeadFollowUpListModel.js.map