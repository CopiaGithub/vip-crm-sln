﻿module GCPL.Controller {
    import app = GCPL.app;
    export class LeadFollowUpListController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("LeadFollowUpListController", LeadDashboardController);

}