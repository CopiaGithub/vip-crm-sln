﻿
module GCPL.Controller {
    import app = GCPL.app;
    export class DeliveryScheduleListController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("DeliveryScheduleListController", DeliveryScheduleListController);
}