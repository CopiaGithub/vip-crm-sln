var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var DeliveryScheduleListModel = /** @class */ (function () {
            function DeliveryScheduleListModel() {
            }
            return DeliveryScheduleListModel;
        }());
        Model.DeliveryScheduleListModel = DeliveryScheduleListModel;
        var DSSearchModel = /** @class */ (function () {
            function DSSearchModel() {
            }
            return DSSearchModel;
        }());
        Model.DSSearchModel = DSSearchModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=DeliveryScheduleListModel.js.map