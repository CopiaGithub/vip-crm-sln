var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        //search
        var LeadChangeListModel = /** @class */ (function () {
            function LeadChangeListModel() {
            }
            return LeadChangeListModel;
        }());
        Model.LeadChangeListModel = LeadChangeListModel;
        var LeadChangeSearchModel = /** @class */ (function () {
            function LeadChangeSearchModel() {
            }
            return LeadChangeSearchModel;
        }());
        Model.LeadChangeSearchModel = LeadChangeSearchModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadChangeListModel.js.map