﻿module GCPL.Controller {
    import app = GCPL.app;
    export class LeadChangeListController extends GCPL.Controller.CoockiesBaseController {

    }


    app.AddController("LeadChangeListController", LeadChangeListController);
}