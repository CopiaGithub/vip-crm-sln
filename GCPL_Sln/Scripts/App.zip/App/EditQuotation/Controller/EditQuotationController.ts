﻿module GCPL.Controller {
    import app = GCPL.app;
    export class EditQuotationController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("EditQuotationController", EditQuotationController);
}