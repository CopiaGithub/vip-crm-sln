var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var EditQuoteModel = /** @class */ (function () {
            function EditQuoteModel() {
            }
            return EditQuoteModel;
        }());
        Model.EditQuoteModel = EditQuoteModel;
        var SearchEditModel = /** @class */ (function () {
            function SearchEditModel() {
            }
            return SearchEditModel;
        }());
        Model.SearchEditModel = SearchEditModel;
        var EditTermsModel = /** @class */ (function () {
            function EditTermsModel() {
            }
            return EditTermsModel;
        }());
        Model.EditTermsModel = EditTermsModel;
        var UpdateQuotationModel = /** @class */ (function () {
            function UpdateQuotationModel() {
            }
            return UpdateQuotationModel;
        }());
        Model.UpdateQuotationModel = UpdateQuotationModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=EditQuotationModel.js.map