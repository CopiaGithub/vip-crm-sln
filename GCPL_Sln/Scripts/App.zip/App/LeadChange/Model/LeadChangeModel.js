var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var EditLeadChangeModel = /** @class */ (function () {
            function EditLeadChangeModel() {
            }
            return EditLeadChangeModel;
        }());
        Model.EditLeadChangeModel = EditLeadChangeModel;
        var LeadStatusForOpenDDModel = /** @class */ (function () {
            function LeadStatusForOpenDDModel() {
            }
            return LeadStatusForOpenDDModel;
        }());
        Model.LeadStatusForOpenDDModel = LeadStatusForOpenDDModel;
        var ReasonForLeadOpenDDModel = /** @class */ (function () {
            function ReasonForLeadOpenDDModel() {
            }
            return ReasonForLeadOpenDDModel;
        }());
        Model.ReasonForLeadOpenDDModel = ReasonForLeadOpenDDModel;
        var UpdateLeadChangeModel = /** @class */ (function () {
            function UpdateLeadChangeModel() {
            }
            return UpdateLeadChangeModel;
        }());
        Model.UpdateLeadChangeModel = UpdateLeadChangeModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadChangeModel.js.map