﻿module GCPL.Controller {
    import app = GCPL.app;
    export class LeadChangeController extends GCPL.Controller.CoockiesBaseController {

    }


    app.AddController("LeadChangeController", LeadChangeController);
}