var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var ReportFollowupSearchModel = /** @class */ (function () {
            function ReportFollowupSearchModel() {
            }
            return ReportFollowupSearchModel;
        }());
        Model.ReportFollowupSearchModel = ReportFollowupSearchModel;
        var ReportFollowupListModel = /** @class */ (function () {
            function ReportFollowupListModel() {
            }
            return ReportFollowupListModel;
        }());
        Model.ReportFollowupListModel = ReportFollowupListModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadFollowUpModel.js.map