﻿module GCPL.Controller {
    import app = GCPL.app;
    export class LeadFollowUpController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("LeadFollowUpController", LeadFollowUpController);

}