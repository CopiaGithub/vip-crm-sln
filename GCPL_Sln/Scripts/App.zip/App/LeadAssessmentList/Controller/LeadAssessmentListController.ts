﻿module GCPL.Controller {
    import app = GCPL.app;
    export class LeadAssessmentListController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("LeadAssessmentListController", LeadAssessmentListController);

}