var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var AssessmentListModel = /** @class */ (function () {
            function AssessmentListModel() {
            }
            return AssessmentListModel;
        }());
        Model.AssessmentListModel = AssessmentListModel;
        var AssessmentSearchModel = /** @class */ (function () {
            function AssessmentSearchModel() {
            }
            return AssessmentSearchModel;
        }());
        Model.AssessmentSearchModel = AssessmentSearchModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=LeadAssessmentListModel.js.map