﻿module GCPL.Controller {
    import app = GCPL.app;
    export class AccessModuleMasterController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("AccessModuleMasterController", AccessModuleMasterController);
}