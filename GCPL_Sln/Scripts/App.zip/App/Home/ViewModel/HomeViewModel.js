var GCPL;
(function (GCPL) {
    var ViewModel;
    (function (ViewModel) {
        var HomeViewModel = /** @class */ (function () {
            function HomeViewModel() {
            }
            return HomeViewModel;
        }());
        ViewModel.HomeViewModel = HomeViewModel;
    })(ViewModel = GCPL.ViewModel || (GCPL.ViewModel = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=HomeViewModel.js.map