﻿module GCPL.ViewModel {
    export class HomeViewModel {
        Id: number;
        Name: string;
    }
}