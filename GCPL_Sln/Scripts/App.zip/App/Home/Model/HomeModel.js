var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var IHomeModel = /** @class */ (function () {
            function IHomeModel() {
            }
            return IHomeModel;
        }());
        Model.IHomeModel = IHomeModel;
        var IFavModel = /** @class */ (function () {
            function IFavModel() {
            }
            return IFavModel;
        }());
        Model.IFavModel = IFavModel;
        var OppStatusModel = /** @class */ (function () {
            function OppStatusModel() {
            }
            return OppStatusModel;
        }());
        Model.OppStatusModel = OppStatusModel;
        var LeadChannelSearchModel = /** @class */ (function () {
            function LeadChannelSearchModel() {
            }
            return LeadChannelSearchModel;
        }());
        Model.LeadChannelSearchModel = LeadChannelSearchModel;
        var SourcePieSearchModel = /** @class */ (function () {
            function SourcePieSearchModel() {
            }
            return SourcePieSearchModel;
        }());
        Model.SourcePieSearchModel = SourcePieSearchModel;
        var LeadDelaylistModel = /** @class */ (function () {
            function LeadDelaylistModel() {
            }
            return LeadDelaylistModel;
        }());
        Model.LeadDelaylistModel = LeadDelaylistModel;
        var OpplistModel = /** @class */ (function () {
            function OpplistModel() {
            }
            return OpplistModel;
        }());
        Model.OpplistModel = OpplistModel;
        var ChannelPieModel = /** @class */ (function () {
            function ChannelPieModel() {
            }
            return ChannelPieModel;
        }());
        Model.ChannelPieModel = ChannelPieModel;
        var ChannelPie1Model = /** @class */ (function () {
            function ChannelPie1Model() {
            }
            return ChannelPie1Model;
        }());
        Model.ChannelPie1Model = ChannelPie1Model;
        var ChannelPieSearchModel = /** @class */ (function () {
            function ChannelPieSearchModel() {
            }
            return ChannelPieSearchModel;
        }());
        Model.ChannelPieSearchModel = ChannelPieSearchModel;
        var SourcePieModel = /** @class */ (function () {
            function SourcePieModel() {
            }
            return SourcePieModel;
        }());
        Model.SourcePieModel = SourcePieModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=HomeModel.js.map