﻿module GCPL.Controller {
    import app = GCPL.app;
    export class AllocationOverrideController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("AllocationOverrideController", AllocationOverrideController);
}