var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var AllocationOverrideListModel = /** @class */ (function () {
            function AllocationOverrideListModel() {
            }
            return AllocationOverrideListModel;
        }());
        Model.AllocationOverrideListModel = AllocationOverrideListModel;
        var AllocationOverrideSearchModel = /** @class */ (function () {
            function AllocationOverrideSearchModel() {
            }
            return AllocationOverrideSearchModel;
        }());
        Model.AllocationOverrideSearchModel = AllocationOverrideSearchModel;
        var InsertAllocationOverrideModel = /** @class */ (function () {
            function InsertAllocationOverrideModel() {
            }
            return InsertAllocationOverrideModel;
        }());
        Model.InsertAllocationOverrideModel = InsertAllocationOverrideModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=AllocationOverrideModel.js.map