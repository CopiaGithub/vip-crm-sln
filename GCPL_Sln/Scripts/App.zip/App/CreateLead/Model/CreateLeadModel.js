var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var CreateLeadListModel = /** @class */ (function () {
            function CreateLeadListModel() {
            }
            return CreateLeadListModel;
        }());
        Model.CreateLeadListModel = CreateLeadListModel;
        var CreateLeadSearchModel = /** @class */ (function () {
            function CreateLeadSearchModel() {
            }
            return CreateLeadSearchModel;
        }());
        Model.CreateLeadSearchModel = CreateLeadSearchModel;
        var LeadStatusddlModel = /** @class */ (function () {
            function LeadStatusddlModel() {
            }
            return LeadStatusddlModel;
        }());
        Model.LeadStatusddlModel = LeadStatusddlModel;
        var CustomerViewModel = /** @class */ (function () {
            function CustomerViewModel() {
            }
            return CustomerViewModel;
        }());
        Model.CustomerViewModel = CustomerViewModel;
        //export class SearchModel {
        //    constructor() {
        //    }
        //    ContactID: string;
        //    CustomerID: string;
        //    LeadID: string;
        //}
        //export class ContactViewModel {
        //    constructor() {
        //    }
        //    ContactID: string;
        //    ContactName: string;
        //    SAPID: string;
        //    PostalCode: string;
        //    Email: string;
        //    MobileNo: string;
        //    Address: string;
        //    PhoneNo: string;
        //    DistrictID: string;
        //    StateID: string;
        //    CountryID: string;
        //    City: string;
        //    Designation: string;
        //    Department: string;
        //    DepartmentID: string;
        //    FOPID: string;
        //    FOP: string;
        //}
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=CreateLeadModel.js.map