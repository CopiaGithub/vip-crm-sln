﻿module GCPL.Controller {
    import app = GCPL.app;
    export class CreateLeadController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("CreateLeadController", CreateLeadController);
}