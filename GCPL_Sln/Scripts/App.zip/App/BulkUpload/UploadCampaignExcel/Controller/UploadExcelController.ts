﻿module GCPL.Controller {
    import app = GCPL.app;
    export class UploadExcelController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("UploadExcelController", UploadExcelController);
}