var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var UploadExcelModel = /** @class */ (function () {
            function UploadExcelModel() {
            }
            return UploadExcelModel;
        }());
        Model.UploadExcelModel = UploadExcelModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=UploadExcelModel.js.map