﻿namespace GCPL.Model {
    export class UploadExcelModel {
        constructor() {
        }

        CampaignID: string;
        FileName: string;
        FilePath: string;
        Status: string;
        UserID: string;
      
    }

   
}