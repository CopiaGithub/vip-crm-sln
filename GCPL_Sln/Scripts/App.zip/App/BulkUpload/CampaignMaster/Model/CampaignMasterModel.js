var GCPL;
(function (GCPL) {
    var Model;
    (function (Model) {
        var InsertCampaignMaster = /** @class */ (function () {
            function InsertCampaignMaster() {
            }
            return InsertCampaignMaster;
        }());
        Model.InsertCampaignMaster = InsertCampaignMaster;
        var CamlistModel = /** @class */ (function () {
            function CamlistModel() {
            }
            return CamlistModel;
        }());
        Model.CamlistModel = CamlistModel;
        var CampaignSearchModel = /** @class */ (function () {
            function CampaignSearchModel() {
            }
            return CampaignSearchModel;
        }());
        Model.CampaignSearchModel = CampaignSearchModel;
        var EditCamlistModel = /** @class */ (function () {
            function EditCamlistModel() {
            }
            return EditCamlistModel;
        }());
        Model.EditCamlistModel = EditCamlistModel;
    })(Model = GCPL.Model || (GCPL.Model = {}));
})(GCPL || (GCPL = {}));
//# sourceMappingURL=CampaignMasterModel.js.map