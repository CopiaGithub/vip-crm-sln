﻿module GCPL.Controller {
    import app = GCPL.app;
    export class CampaignMasterController extends GCPL.Controller.CoockiesBaseController {

    }
    app.AddController("CampaignMasterController", CampaignMasterController);
}